//
//  CollectionViewCell.swift
//  Music
//
//  Created by Rao on 10/11/20.
//

import UIKit


class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var image1: UIImageView!
    
    @IBOutlet weak var label1: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
