//
//  CollectionViewCell1.swift
//  Music
//
//  Created by Rao on 10/11/20.
//

import UIKit

class CollectionViewCell1: UICollectionViewCell {

    @IBOutlet weak var icon1: UIImageView!
    @IBOutlet weak var song1: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
