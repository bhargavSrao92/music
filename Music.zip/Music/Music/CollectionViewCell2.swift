//
//  CollectionViewCell2.swift
//  Music
//
//  Created by Rao on 10/11/20.
//

import UIKit

class CollectionViewCell2: UICollectionViewCell {
    @IBOutlet weak var fillhilla: UILabel!
    
    @IBOutlet weak var tracks: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
