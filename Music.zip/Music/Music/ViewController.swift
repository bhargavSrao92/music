//
//  ViewController.swift
//  Music
//
//  Created by Rao on 10/11/20.
//

import UIKit
class ViewController: UIViewController {
    
    @IBOutlet weak var collectionview1: UICollectionView!

    @IBOutlet weak var collectionview3: UICollectionView!
    @IBOutlet weak var collectionview2: UICollectionView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
self.collectionview1.register(UINib(nibName: "CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "cellxib")
view.addSubview(collectionview1)
        collectionview1.backgroundColor = UIColor.clear
        
        
        
        
        self.collectionview2.register(UINib(nibName: "CollectionViewCell1", bundle: nil), forCellWithReuseIdentifier: "cellxib2")
        view.addSubview(collectionview2)
        collectionview2.backgroundColor = UIColor.clear
        
        
        self.collectionview3.register(UINib(nibName: "CollectionViewCell2", bundle: nil), forCellWithReuseIdentifier: "cellxib3")
        view.addSubview(collectionview3)
        collectionview3.backgroundColor = UIColor.clear
        
        
         var preferredStatusBarStyle: UIStatusBarStyle {
            return .lightContent
        }
}

}

extension ViewController : UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
 return 6
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        
        
        if collectionView == self.collectionview1 {
            let myCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellxib", for: indexPath as IndexPath) as! CollectionViewCell
            myCell.label1.text = "fillhall"
               return myCell
            
        }
        else if collectionView == self.collectionview2{
            let myCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellxib2", for: indexPath as IndexPath) as! CollectionViewCell1
           // myCell.song1.text = "songname"
               return myCell

            
        }
        else{
            let myCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellxib3", for: indexPath as IndexPath) as! CollectionViewCell2
           // myCell.song1.text = "songname"
               return myCell

            
            
            
            
            
        }
}
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
         return 1
     }


}

